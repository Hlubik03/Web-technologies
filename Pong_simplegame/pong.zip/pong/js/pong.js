var lopta_x;						// pozicia lopty x [px]
var lopta_y;						// pozicia lopty y [px]
var lopta_smer_x;					// smer pohybu x [kladny - zlava doprava / zaporny naopak]
var lopta_smer_y;					// smer pohybu y [kladny - zhora nadol / zaporny naopak]
var lopta_rychlost_x = 500;			// rychlost lopty v smere x [pixelov za sekundu]
var lopta_rychlost_y = 400;			// rychlost lopty v smere y [pixelov za sekundu]
var padlo_x = 0;					// pozicia padla x
var padlo_y = 580;					// pozicia padla y [nemeni sa]
var mys_x;							// pozicia mysi x
var mys_y;							// pozicia mysi y
var interval = 0.01;				// ako casto pocitame pohyb lopty [sekundy]
var milis;							// cas intervalu v milisekundach
var lopta;							// globalna referencia na loptu
var padlo;							// globalna referencia na padlo
var plocha;							// globalna referencia na plochu
var casovac;						// globalna referencia na casovac

window.onload = function() {		// spusti sa po nacitani obj. window

};

function vratPoziciu(element) {			// vypocita a vrati presnu poziciu elementu v ramci zobrazovanej casti okna 
	elem_x = (element.offsetLeft - element.scrollLeft + element.clientLeft);
	elem_y = (element.offsetTop - element.scrollTop + element.clientTop);
	return {x: elem_x, y: elem_y};		// vracia objekt s dvomi hodnotami
}

document.onmousemove = function(e) {	// definuje event listener pre udalost pohybu mysi v ramci aktivneho dokumentu
	mys_x = e.clientX;					// zapise x suradnicu mysi do glob. premennej
	mys_y = e.clientY;					// zapise y suradnicu mysi do glob. premennej
}