// Definovanie premennych (globalne)
var F = 0.8;
var k11 = 0.5;
var q0s = 0.5;
var hs = (q0s/k11)*(q0s/k11);
var x = hs;
var dt = 0.01;
var t = 0;
var q0 = q0s;

// Numericke riesenie diferencialnej rovnice zasobnika kvapaliny
function rk4() {
	var x_n = x;

	var k1 = dt * model();

	x = x_n + k1/2
	var k2 = dt * model();

	x = x_n + k2/2
	var k3 = dt * model();

	x = x_n + k3
	var k4 = dt * model();

	x = x_n + (k1 + 2*k2 + 2*k3 + k4)/6;
	t = t + dt;

	if(x < 0.001)
		x = 0.001;
}

// Model zasobnika kvapaliny
function model() {
	var dx = q0/F - k11*Math.sqrt(x)/F;
	return dx;
}
